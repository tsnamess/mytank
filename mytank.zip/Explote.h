#ifndef __EXPLOTE__
#define __EXPLOTE__

#include <graphics.h>

class Explote
{
protected:
	COLORREF m_color;
};


#endif __EXPLOTE__
